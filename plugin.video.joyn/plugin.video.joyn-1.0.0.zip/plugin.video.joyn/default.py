# -*- coding: utf-8 -*-
#entrypoint
from resources.lib import plugin
