# plugin.video.zattooHiQ-19
Play Live TV and recorded shows from Zattoo.

Support: https://www.kodinerds.net/index.php/Thread/68785-ZattooHiQ-19/?postID=573693#post573693
***
Only for Kodi-19 Matrix
***
