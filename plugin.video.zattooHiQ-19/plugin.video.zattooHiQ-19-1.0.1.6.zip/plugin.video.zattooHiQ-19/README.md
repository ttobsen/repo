# plugin.video.zattooHiQ-19
Play Live TV and recorded shows from Zattoo.

Support: [Kodinerds/ZattooHiQ-19](https://www.kodinerds.net/index.php/Thread/68785-ZattooHiQ-19/?postID=573693#post573693)
