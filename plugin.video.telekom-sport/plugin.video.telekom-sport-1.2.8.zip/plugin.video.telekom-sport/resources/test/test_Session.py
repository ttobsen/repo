# -*- coding: utf-8 -*-
# Module: Session
# Author: asciidisco
# Created on: 24.07.2017
# License: MIT https://goo.gl/xF5sC4

"""Tests for the `Session` module"""

import unittest
from resources.lib.Session import Session

class SessionTestCase(unittest.TestCase):
    """Tests for the `Session` module"""

    def test_dummy(self):
        """ADD ME"""
        self.assertEqual(True, True)
